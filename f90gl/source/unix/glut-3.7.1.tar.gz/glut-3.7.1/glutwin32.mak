

# Be sure to modify the definitions in this file to agree with your

# systems installation.

#  NOTE: be sure that the install directories use '\' not '/' for paths.



# Microsoft Visual C++ 4.x install directories

LIBINSTALL     = c:\msdev\lib

INCLUDEINSTALL = c:\msdev\include\GL

# Microsoft Visual C++ 5.0 install directories

LIBINSTALL     = "c:\Program Files\DevStudio\VC\lib"

INCLUDEINSTALL = "c:\Program Files\DevStudio\VC\include\GL"



# Win95 dll directory

#DLLINSTALL     = c:\windows\system



# WinNT dll directory

DLLINSTALL     = c:\winnt\system32



# Microsoft OpenGL libraries

#

MS_GLU     = glu32.lib

MS_OPENGL  = opengl32.lib

MS_GLUT    = $(TOP)/lib/glut/glut32.lib

MS_GLUTLIB = glut32.lib

MS_GLUTDLL = glut32.dll



# SGI OpenGL for Windows libraries (formerly Cosmo OpenGL)

#

SGI_GLU     = \oglsdk\lib\glu.lib

SGI_OPENGL  = \oglsdk\lib\opengl.lib

SGI_GLUT    = $(TOP)/lib/glut/glut.lib

SGI_GLUTLIB = glut.lib

SGI_GLUTDLL = glut.dll



# >> See note below about enabling SGI OpenGL for Windows support.

GLU     = $(MS_GLU)

OPENGL  = $(MS_OPENGL)

GLUT    = $(MS_GLUT)

GLUTLIB = $(MS_GLUTLIB)

GLUTDLL = $(MS_GLUTDLL)



# >> To use SGI OpenGL, uncomment lines below and comment out the similiar

# >> lines above.  You can download SGI OpenGL for Windows for

# >> free from http://www.meer.net/~gold/OpenGL/opengl2.exe

#GLU     = $(SGI_GLU)

#OPENGL  = $(SGI_OPENGL)

#GLUT    = $(SGI_GLUT)

#GLUTLIB = $(SGI_GLUTLIB)

#GLUTDLL = $(SGI_GLUTDLL)



# The Micro UI lib

MUI     = $(TOP)/lib/mui/mui.lib



# The OpenGL Extrusion and Tubing lib

GLE     = $(TOP)/lib/gle/gle.lib



# The OpenGL Sphere Mapping lib

GLSMAP  = $(TOP)/lib/glsmap/glsmap.lib



# common definitions used by all makefiles

CFLAGS	= $(cflags) $(cdebug) $(EXTRACFLAGS) -DWIN32 -I$(TOP)/include

LIBS	= $(lflags) $(ldebug) $(EXTRALIBS) $(GLUT) $(GLU) $(OPENGL) $(guilibs)

EXES	= $(SRCS:.c=.exe) $(CPPSRCS:.cpp=.exe)



!IFNDEF NODEBUG

lcommon = /NODEFAULTLIB /INCREMENTAL:NO /DEBUG /NOLOGO

!ENDIF



# default rule

default	: $(EXES)



# cleanup rules

clean	::

	@del /f *.obj

	@del /f *.pdb

	@del /f *.ilk

	@del /f *.ncb

	@del /f *~

	@del /f *.exp



clobber	:: clean

	@del /f *.exe

	@del /f *.dll

	@del /f *.lib

	-@del /f $(LDIRT)



# inference rules

$(EXES)	: $*.obj $(DEPLIBS)

	echo $@

        $(link) -out:$@ $** $(LIBS)

.c.obj	: 

	$(CC) $(CFLAGS) $<

.cpp.obj : 

	$(CC) $(CFLAGS) $<

